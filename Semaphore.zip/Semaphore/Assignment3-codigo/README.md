# Assignment3
Assignment with Jena API in Java
