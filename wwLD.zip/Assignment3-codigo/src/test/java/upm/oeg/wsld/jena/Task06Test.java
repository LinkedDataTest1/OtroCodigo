package upm.oeg.wsld.jena;

import org.junit.*;
import static org.junit.Assert.*;

public class Task06Test {
 
    @Test
    public void test() {
		Task06.main(null);
        assertEquals(true,true);
    }
}