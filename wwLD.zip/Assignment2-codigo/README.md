# Assignment2
Creación de RDF
