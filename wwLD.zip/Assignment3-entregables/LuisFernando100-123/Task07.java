public class Task07 {

	public static void main(String[] args) {
		//stub
	}

	public static int substract(int a, int b){
		//TODO
		return a-b;
	}

}