package upm.oeg.wsld.jena;

import org.junit.*;
import static org.junit.Assert.*;

public class Task07Test {
 
    @Test
    public void test() {
		Task07.main(null);
        assertEquals(true,true);
    }
}